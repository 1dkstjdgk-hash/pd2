#include <stdio.h>

void even(){
	printf("1818!");
}

void odd(){
	printf("9797!");
}

void main() {
	int number;
	printf("������ �Է��Ͻÿ�:");
	scanf("%d", &number);
	if(number % 2 == 0)
		even();
	else
		odd(); 
	
}
