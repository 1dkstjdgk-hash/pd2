#include <stdio.h>

void star(int i){
	int j;
	for(j = 1; j <= i; j++){
		printf("*");
	}
}

void main() {
	int number;
	printf("������ �Է��Ͻÿ�:");
	scanf("%d", &number);
	star(number);
}
